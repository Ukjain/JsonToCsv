package org.jsontocsv;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jsontocsv.parser.JSONFlattener;
import org.jsontocsv.writer.CSVWriter;

/**
 * @author smn
 * Def:This program is working on JSON file convert to CSV file complete.
 */
public class Main {

    public static void main(String[] args) throws Exception {
        List<Map<String, String>> flatJson = JSONFlattener.parseJson(jsonString());
        /* *  
        /*
         *  Parse a Large JSON File and convert it to CSV   world_bank.json
         */
       flatJson = JSONFlattener.parseJson(new File("/home/smn/Desktop/JSON_File/simple.Json"), "UTF-8");
        // Using ';' as separator
       Set<String> header = CSVWriter.collectOrderedHeaders(flatJson);
        // the intention is generate a csv file with specific headers - not all
       CSVWriter.writeLargeFile(flatJson, ";", "/home/smn/Desktop/JSON_File/World_AL4Geo.csv", header);     
    }
    private static String jsonString() {
        return  "[" +
                "    {" +
                "        \"studentName\": \"Foo\"," +
                "        \"Age\": \"12\"," +
                "        \"subjects\": [" +
                "            {" +
                "                \"name\": \"English\"," +
                "                \"marks\": \"40\"" +
                "            }," +
                "            {" +
                "                \"name\": \"History\"," +
                "                \"marks\": \"50\"" +
                "            }" +
                "        ]" +
                "    }" +
                "]";
    }
}
